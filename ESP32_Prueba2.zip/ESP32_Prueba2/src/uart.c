#include "uart.h"
void imprimir_pantalla(int16_t SW1, int cambio);
void imprimir_pantalla2(int16_t SW1, int16_t SW2, boolean cambio1, boolean cambio2);