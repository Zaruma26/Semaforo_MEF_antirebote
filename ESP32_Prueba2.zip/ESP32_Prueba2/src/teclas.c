#include "teclas.h"

//Funciones utilizadas para el punto 1
int buttonPressed1(int16_t tecla, fsmTecla Tecla);
boolean fsmAnti_rebote(int16_t SW, fsmTecla* Tecla);
int buttonReleassed(int16_t tecla, fsmTecla Tecla);

int buttonPressed(int16_t tecla, fsmTecla Tecla);
boolean fsmAnti_rebote2(int16_t SW, fsmTecla* Tecla);
int buttonReleassed1(int16_t tecla, fsmTecla Tecla);

fsmTecla fsmInicializar(void);

//Funcion utilizada para el punto 2
void actualizarMEF(dbn_t *dataTecla1, dbn_t *dataTecla2, int16_t pulsante1, int16_t pulsante2);