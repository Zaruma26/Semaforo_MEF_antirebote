#include "Semaforo.h"

//Esta funcion devuelve en que estado comienza el semaforo
estado_semaforo semaforo_inicio(void);
//La funcion recibe como argumentos los switchs, los leds y el estado de inicio como puntero
int semaforo_cambio(int16_t SW1, int16_t SW2, estado_semaforo *estado_semaforo_t, int16_t LED_Amarillo, int16_t LED_Rojo, int16_t LED_Verde);
